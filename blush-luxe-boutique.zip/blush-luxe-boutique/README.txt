Blush & Luxe Boutique Website Project

Required pages from the proposal:
- index.html — Store Homepage
- shop.html — Shop
- product-details.html — Product Details
- cart.html — Cart
- checkout.html — Checkout
- about.html — About and Contact

Additional page from the visual site map:
- order-confirmation.html — Order Confirmation

External stylesheet:
- styles.css

Local product images:
- images/handbag.svg
- images/wallet.svg
- images/bracelet.svg
- images/sunglasses.svg
- images/beauty-bag.svg

All HTML pages link to styles.css.
Open index.html in a browser to start.
